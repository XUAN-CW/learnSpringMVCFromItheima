//package com.itheima.domain;
//
//public class User {
//
//    private int number;
//    private int remaining;
//    private int integral;
//    private String time;
//
//    public int getNumber() {
//        return number;
//    }
//
//    public void setNumber(int number) {
//        this.number = number;
//    }
//
//    public int getRemaining() {
//        return remaining;
//    }
//
//    public void setRemaining(int remaining) {
//        this.remaining = remaining;
//    }
//
//    public int getIntegral() {
//        return integral;
//    }
//
//    public void setIntegral(int integral) {
//        this.integral = integral;
//    }
//
//    public String getTime() {
//        return time;
//    }
//
//    public void setTime(String time) {
//        this.time = time;
//    }
//
//
//    @Override
//    public String toString() {
//        return "User{" +
//                "number=" + number +
//                ", remaining=" + remaining +
//                ", integral=" + integral +
//                ", time='" + time + '\'' +
//                '}';
//    }
//}
